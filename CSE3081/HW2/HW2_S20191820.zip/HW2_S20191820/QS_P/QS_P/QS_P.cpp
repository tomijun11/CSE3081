#define INPUT_FILE_NAME "input_data_rd_65536.bin"
#define OUTPUT_FILE_NAME "output_QS_P.bin"
#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <limits.h>
#include <math.h>

/******************************************************************************************************/
#include <Windows.h>
#define CHECK_TIME_START(start,freq) QueryPerformanceFrequency((LARGE_INTEGER*)&freq); QueryPerformanceCounter((LARGE_INTEGER*)&start)
#define CHECK_TIME_END(start,end,freq,time) QueryPerformanceCounter((LARGE_INTEGER*)&end); time = (float)((float)(end - start) / (freq * 1.0e-3f))

__int64 _start, _freq, _end;
float compute_time;
/******************************************************************************************************/

int SWAP_temp;
#define SWAP(a, b) {SWAP_temp = a; a = b; b = SWAP_temp;}

int Quick_Sort_P(unsigned int* data, int left, int right);
void QuickP_sorting(unsigned int* data, int left, int right);
int QuickP_partition(unsigned int* data, int left, int right);
int median_of_three(int X1, int X2, int X3);

int main(void)
{
	FILE* fin = fopen(INPUT_FILE_NAME, "rb");
	if (fin == NULL)
	{
		printf("������ �����ϴ�.\n");
		return -1;
	}
	int total;
	fread(&total, sizeof(int), 1, fin);
	unsigned int temp, * data = (unsigned int*)malloc(sizeof(unsigned int) * total);

	for (int i = 0; i < total; i++) {
		fread(&temp, sizeof(int), 1, fin);
		data[i] = temp;
	}

	if (Quick_Sort_P(data, 0, total - 1))
		printf("���Ŀ� �����߽��ϴ�.\n");

	printf("\n^^^ Time for sorting %d elements = %.3fms\n\n", total, compute_time);
	
	FILE* fp;
	if ((fp = fopen(OUTPUT_FILE_NAME, "wb")) == NULL) {
		fprintf(stderr, "Error: cannot open the binary file %s for writing...\n", OUTPUT_FILE_NAME);
		exit(-1);
	}

	fwrite(&total, sizeof(int), 1, fp); // N_ELEMENTS ���
	for (int i = 0; i < total; i++) {
		temp = data[i];
		fwrite(&temp, sizeof(int), 1, fp);
	}

	fclose(fin);
	fclose(fp);

}

int median_of_three(int X1, int X2, int X3)
{
	if (X1 > X2)
	{
		if (X3 > X1)
			return X1; // X3 X1 X2
		else
		{
			if (X3 > X2)
				return X3; // X1 X3 X2
			else
				return X2; // X1 X2 X3
		}
	}
	else // X1 < X2
	{
		if (X3 > X2)
			return X2; // X3 X2 X1
		else
		{
			if (X3 > X1)
				return X3; // X2 X3 X1
			else
				return X1; // X2 X1 X3
		}
	}
}

int Quick_Sort_P(unsigned int* data, int left, int right) {
	CHECK_TIME_START(_start, _freq);
	QuickP_sorting(data, left, right);
	CHECK_TIME_END(_start, _end, _freq, compute_time);

	for (int i = left; i < right - 1; i++) {
		if (data[i] > data[i + 1])
			return 1;
	}
	return 0;
}

int qstemp;
void QuickP_sorting(unsigned int* data, int left, int right)
{
	qstemp = right - left;
	if (qstemp <= 0) return;
	if (qstemp >= 3)
	{
		SWAP(data[median_of_three(left, (left + right) / 2, right)], data[left]);
		int pivot = QuickP_partition(data, left, right);

		QuickP_sorting(data, left, pivot - 1);
		QuickP_sorting(data, pivot + 1, right);
	}
	else if (qstemp == 2)
	{
		if (data[left + 2] < data[left + 1])
			SWAP(data[left + 2], data[left + 1]);
		if (data[left + 1] < data[left + 0])
			SWAP(data[left + 1], data[left + 0]);
		if (data[left + 2] < data[left + 1])
			SWAP(data[left + 2], data[left + 1]);
	}
	else
	{
		if (data[right] < data[left])
			SWAP(data[right], data[left]);
	}
}

int QuickP_partition(unsigned int* data, int left, int right)
{
	int j = left;
	for (int i = left + 1; i <= right; i++)
	{
		if (data[i] < data[left])
		{
			j++;
			SWAP(data[i], data[j]);
		}
	}
	SWAP(data[j], data[left]);
	return j;
}