#define INPUT_FILE_NAME "input_data_rd_65536.bin"
#define OUTPUT_FILE_NAME "output_IS.bin"
#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <limits.h>
#include <math.h>

/******************************************************************************************************/
#include <Windows.h>
#define CHECK_TIME_START(start,freq) QueryPerformanceFrequency((LARGE_INTEGER*)&freq); QueryPerformanceCounter((LARGE_INTEGER*)&start)
#define CHECK_TIME_END(start,end,freq,time) QueryPerformanceCounter((LARGE_INTEGER*)&end); time = (float)((float)(end - start) / (freq * 1.0e-3f))

__int64 _start, _freq, _end;
float compute_time;
/******************************************************************************************************/

int Insertion_Sort(unsigned int* data, int left, int right);

int main(void)
{
	FILE* fin = fopen(INPUT_FILE_NAME, "rb");
	if (fin == NULL)
	{
		printf("������ �����ϴ�.\n");
		return -1;
	}
	int total;
	fread(&total, sizeof(int), 1, fin);
	unsigned int temp, * data = (unsigned int*)malloc(sizeof(unsigned int) * total);

	for (int i = 0; i < total; i++) {
		fread(&temp, sizeof(int), 1, fin);
		data[i] = temp;
	}

	if (Insertion_Sort(data, 0, total - 1))
		printf("���Ŀ� �����߽��ϴ�.\n");

	printf("\n^^^ Time for sorting %d elements = %.3fms\n\n", total, compute_time);


	FILE* fp;
	if ((fp = fopen(OUTPUT_FILE_NAME, "wb")) == NULL) {
		fprintf(stderr, "Error: cannot open the binary file %s for writing...\n", OUTPUT_FILE_NAME);
		exit(-1);
	}
	
	fwrite(&total, sizeof(int), 1, fp); // N_ELEMENTS ���
	for (int i = 0; i < total; i++) {
		temp = data[i];
		fwrite(&temp, sizeof(int), 1, fp);
	}

	fclose(fin);
	fclose(fp);
}

int Insertion_Sort(unsigned int* data, int left, int right) {
	CHECK_TIME_START(_start, _freq);
	for (int i = left; i <= right; i++) {
		unsigned int key = data[i];
		int j = i - 1;
		for (; j >= 0 && key < data[j]; j--) {
			data[j + 1] = data[j];
		}
		data[j + 1] = key;
	}
	CHECK_TIME_END(_start, _end, _freq, compute_time);

	for (int i = left; i < right - 1; i++) {
		if (data[i] > data[i + 1])
			return 1;
	}
	return 0;
}
