#define INPUT_FILE_NAME "input_data_rd_65536.bin"
#define OUTPUT_FILE_NAME "output_MS.bin"
#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <limits.h>
#include <math.h>

/******************************************************************************************************/
#include <Windows.h>
#define CHECK_TIME_START(start,freq) QueryPerformanceFrequency((LARGE_INTEGER*)&freq); QueryPerformanceCounter((LARGE_INTEGER*)&start)
#define CHECK_TIME_END(start,end,freq,time) QueryPerformanceCounter((LARGE_INTEGER*)&end); time = (float)((float)(end - start) / (freq * 1.0e-3f))

__int64 _start, _freq, _end;
float compute_time;
/******************************************************************************************************/

int Merge_Sort(unsigned int* data, int left, int right);
void Merge_sorting(unsigned int* data, int left, int right);
void Merge_combine(unsigned int* data, int left, int cntr, int right);
unsigned int* tmpdata;

int main(void)
{
	FILE* fin = fopen(INPUT_FILE_NAME, "rb");
	if (fin == NULL)
	{
		printf("������ �����ϴ�.\n");
		return -1;
	}
	int total;
	fread(&total, sizeof(int), 1, fin);
	unsigned int temp, * data = (unsigned int*)malloc(sizeof(unsigned int) * total);

	for (int i = 0; i < total; i++) {
		fread(&temp, sizeof(int), 1, fin);
		data[i] = temp;
	}

	if (Merge_Sort(data, 0, total - 1))
		printf("���Ŀ� �����߽��ϴ�.\n");

	printf("\n^^^ Time for sorting %d elements = %.3fms\n\n", total, compute_time);
	
	FILE* fp;
	if ((fp = fopen(OUTPUT_FILE_NAME, "wb")) == NULL) {
		fprintf(stderr, "Error: cannot open the binary file %s for writing...\n", OUTPUT_FILE_NAME);
		exit(-1);
	}

	fwrite(&total, sizeof(int), 1, fp); // N_ELEMENTS ���
	for (int i = 0; i < total; i++) {
		temp = data[i];
		fwrite(&temp, sizeof(int), 1, fp);
	}

	fclose(fin);
	fclose(fp);
}

int Merge_Sort(unsigned int* data, int left, int right) {
	CHECK_TIME_START(_start, _freq);
	tmpdata = (unsigned int*)malloc(sizeof(int) * (right - left + 1));
	Merge_sorting(data, left, right);
	CHECK_TIME_END(_start, _end, _freq, compute_time);

	for (int i = left; i < right - 1; i++) {
		if (data[i] > data[i + 1])
			return 1;
	}
	return 0;
}

void Merge_sorting(unsigned int* data, int left, int right)
{
	if (right - left > 0)
	{
		int cntr = (left + right) / 2;

		Merge_sorting(data, left, cntr);
		Merge_sorting(data, cntr + 1, right);

		Merge_combine(data, left, cntr, right);
	}
}

void Merge_combine(unsigned int* data, int left, int cntr, int right)
{
	memcpy(tmpdata + left, data + left, (right - left + 1) * sizeof(int));
	int lptr = left, rptr = cntr + 1, curptr = left;
	while (lptr <= cntr && rptr <= right)
	{
		if (tmpdata[lptr] <= tmpdata[rptr])
			data[curptr++] = tmpdata[lptr++];
		else
			data[curptr++] = tmpdata[rptr++];
	}
	while (lptr <= cntr)
		data[curptr++] = tmpdata[lptr++];
	while (rptr <= right)
		data[curptr++] = tmpdata[rptr++];
}


