#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct _component {
	int V;
	int64_t total_weight;
}MST;

typedef struct _subset
{
	int rank;
	int parent;
}Subset;

typedef struct _edge
{
	int src;
	int dest;
	int weight;
}Edge;

typedef struct _edgelist
{
	int E; // |E|
	int V; // |V|
	int MAX_WEIGHT;
	Edge* List;
}EdgeList;

int TotalNum = 0, IsolatedNum = 0, retsize = 0, heapsize = 0, K_scanned = 0;
Subset* set;
MST *component;
EdgeList graph;
Edge* result;

void adjust(Edge* minHeap, int root) // O(log(E))
{
	Edge Root = minHeap[root];
	int child = root * 2;

	while (child <= heapsize)
	{
		if ((child < heapsize) && (minHeap[child].weight > minHeap[child+1].weight)) // ���� �� �������� ����
			child++;
		if (Root.weight < minHeap[child].weight) // root�� minheap�� �����ϸ� break
			break;
		else // root�� �Ѵܰ� ���� (���õ� child�� root �ڸ��� �ø�)
		{
			minHeap[child / 2] = minHeap[child];
			child *= 2;
		}
	}
	minHeap[child / 2] = Root; // ���� ���õ� ��ġ�� Root ����
}

void Make_Heap() // O(E)
{
	for (int i = graph.E / 2; i > 0; i--) 
		adjust(graph.List, i); // ȣ��� heapsize�� graph.E�� ����
}

Edge Delete_Heap() // O(log(E))
{
	Edge tmp = graph.List[1];
	graph.List[1] = graph.List[heapsize];
	heapsize--;
	adjust(graph.List, 1);
	return tmp;
}

int Find(int x) // path compression, O(log(V))
{
	int root = x;
	while (set[root].parent != root) // find root
		root = set[root].parent;
	
	while (set[x].parent != x)
	{
		int tmp = set[x].parent;
		set[x].parent = root; // x->root�� ��� ���� ��� parent�� root�� ������
		x = tmp;
	}	
	return root;
}


void Union(int x, int y) // O(log(V))
{
	int xroot = Find(x);
	int yroot = Find(y);

	if (xroot == yroot) // ���� set -> Union ����
		return;

	if (set[xroot].rank > set[yroot].rank)
		set[yroot].parent = xroot;
	else if (set[xroot].rank < set[yroot].rank)
		set[xroot].parent = yroot;
	else // rank�� ������ y�� ���� �ø�
	{
		set[xroot].parent = yroot;
		set[yroot].rank += 1;
	}
}

void Kruskal() // O(Elog(V))
{
	K_scanned = graph.E;
	clock_t start = clock();
	Make_Heap();
	for (int i = 0; i < graph.V; i++) // Makeset
	{
		set[i].parent = i;
		set[i].rank = 0;
	}

	for (int i = 1; i <= graph.E; i++) // index 1���� ����
	{
		Edge cur = Delete_Heap();

		int xroot = Find(cur.src);
		int yroot = Find(cur.dest);

		if (xroot != yroot) // �ٸ� ���տ� ���Ҷ��� MST�� �߰�
		{
			result[retsize++] = cur;
			Union(xroot, yroot);
		}

		if (retsize >= graph.V - 1) // MST�� �̹� ��� ���������� break
		{
			K_scanned = i;
			break;
		}
	}
	clock_t end = clock();
	printf("K_scanned : %d\nTotal Time: %.3lf\n", K_scanned, double(end - start) / CLOCKS_PER_SEC);
}

void remove_endl(char str[]) // fgets \n ����
{
	if (str[strlen(str) - 1] == '\n')
		str[strlen(str) - 1] = '\0';
}


int main(void)
{
	FILE* fptr, * finput, * foutput;
	fopen_s(&fptr, "commands.txt", "r");

	if (fptr == NULL)
	{
		printf("commands.txt doesn't exist!\n");
		return -1;
	}
	char buffer[256] = { 0 }, fname[512] = { 0 }, rname[256] = { 0 };
	fgets(buffer, 256, fptr);
	remove_endl(buffer);
	strcpy_s(fname, 512, buffer);
	fgets(buffer, 256, fptr);
	strcat_s(fname, 512, "\\");
	strcat_s(fname, 512, buffer);
	remove_endl(fname);
	fgets(rname, 256, fptr);
	remove_endl(rname);
	fclose(fptr);


	// read input
	fopen_s(&finput, fname, "r");
	if (finput == NULL)
	{
		printf("%s doesn't exist!\n", fname);
		return -1;
	}

	fscanf_s(finput, "%d %d %d", &graph.V, &graph.E, &graph.MAX_WEIGHT);

	set = (Subset*)malloc(sizeof(Subset) * graph.V);
	component = (MST*)malloc(sizeof(MST) * graph.V);
	graph.List = (Edge*)malloc(sizeof(Edge) * (graph.E+1)); // index 1���� ����
	result = (Edge*)malloc(sizeof(Edge) * (graph.V - 1));
	heapsize = graph.E;
	for (int i = 1; i <= graph.E; i++)
		fscanf_s(finput, "%d %d %d", &(graph.List[i].src), &(graph.List[i].dest), &(graph.List[i].weight));
	for (int i = 0; i < graph.V; i++)
	{
		component[i].V = 0;
		component[i].total_weight = 0;
	}
	fclose(finput);


	// Make Minimum spanning forest
	Kruskal();

	// Count Isolated component
	for (int i = 0; i < graph.V; i++)
		if (set[i].parent == i && set[i].rank == 0)
		{
			TotalNum++;
			IsolatedNum++;
		}

	// Calc Minimun spanning trees
	for (int i = 0; i < retsize; i++)
	{
		int root = Find(result[i].src);
		if (component[root].V == 0)
			component[root].V = 2;
		else
			component[root].V++;
		component[root].total_weight += result[i].weight;
	}

	// Count connected component
	for (int i = 0; i < graph.V; i++)
		if (component[i].V > 0)
			TotalNum++;

	// write output
	fopen_s(&foutput, rname, "w");
	if (foutput == NULL)
	{
		printf("file write error\n");
		return -1;
	}

	fprintf(foutput, "%d\n", TotalNum);
	for (int i = 0; i < graph.V; i++)
		if (component[i].V > 0)
			fprintf(foutput, "%d %lld\n", component[i].V, component[i].total_weight);
	for (int i = 0; i < IsolatedNum; i++)
		fprintf(foutput, "1 0\n");

	fclose(foutput);
	free(result);
	free(set);
	free(component);
	free(graph.List);
	return 0;
}

