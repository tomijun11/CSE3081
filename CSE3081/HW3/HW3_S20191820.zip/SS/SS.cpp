#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void print_path(FILE* fout, int* LArr, int i, int j);
int** table, ** path, count;

int main(void)
{
	FILE* fp = fopen("SS_test_command.txt", "r");

	int fnum, i, j, k;
	char fnamei[50], fnameo[50];
	fscanf(fp,"%d",&fnum);
	for (i = 0; i < fnum; i++)
	{
		FILE* fin, * fout;
		fscanf(fp, "%s %s", fnamei, fnameo);
		
		fin = fopen(fnamei, "r");
		fout = fopen(fnameo, "w");

		if (fin == NULL)
		{
			fclose(fin);
			fclose(fout);
			continue;
		}
		
		int num, * LArr, Length;
		fscanf(fin, "%d", &num);
		LArr = (int*)malloc(sizeof(int) * num);
		for (j = 0; j < num; j++)
		{
			fscanf(fin, "%d", &(LArr[j]));
		}
		fscanf(fin, "%d", &Length);

		table = (int**)malloc(sizeof(int*) * (num+1));
		for (j = 0; j <= num; j++)
			table[j] = (int*)malloc(sizeof(int) * (Length+1));

		path = (int**)malloc(sizeof(int*) * (num + 1));
		for (j = 0; j <= num; j++)
			path[j] = (int*)malloc(sizeof(int) * (Length + 1));
		
		table[0][0] = 1;
		path[0][0] = 2;
		for (j = 1; j <= Length; j++)
		{
			table[0][j] = 0;
			path[0][j] = 2;
		}
		
		for (k = 1; k <= num; k++)
		{
			for (j = 0; j <= Length; j++)
			{
				if (LArr[k-1] <= j)
				{
					// �Ѵ� True�� ���þ������� ������
					if (table[k - 1][j] >= table[k - 1][j - LArr[k - 1]]) // i�� ���� ����
					{
						table[k][j] = table[k - 1][j];
						path[k][j] = 0;
					}
					else // i�� ������
					{
						table[k][j] = table[k - 1][j - LArr[k - 1]];
						path[k][j] = 1;
					}
				}
				else
				{
					table[k][j] = table[k - 1][j];
					path[k][j] = 0;
				}
			}
		}


		fprintf(fout, "%d\n", table[num][Length]);
		if (table[num][Length] == 1)
		{
			count = 0;
			print_path(fout,LArr,num,Length);
		}


		for (j = 0; j <= num; j++)
		{
			free(table[j]);
			free(path[j]);
		}
		free(table);
		free(path);

		free(LArr);
		fclose(fin);
		fclose(fout);
	}


	fclose(fp);
	return 0;
}

void print_path(FILE* fout, int* LArr, int i, int j)
{
	if (i <= 0) // path[0][j] = 2
	{
		fprintf(fout, "%d\n", count);
		return;
	}

	if (path[i][j] == 0) // ���� ����
	{
		print_path(fout, LArr, i - 1, j);
	}
	else // ������
	{
		count++;
		print_path(fout, LArr, i - 1, j - LArr[i - 1]);
		fprintf(fout, "%d\n", i - 1);
	}
}