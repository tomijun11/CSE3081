#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

double dist(int n, int v1, int v2);

int ** path;
double* XArr, * YArr, **table;

typedef struct _chord
{
	int v1;
	int v2;
}chord;
chord* CArr;
int Cnum;
void Insertion_Sort1(chord* data, int left, int right);
void Insertion_Sort2(chord* data, int left, int right);
void save_path(int num, int i, int j);
int check_adj(int n, int v1, int v2);
int main(void)
{
	FILE* fp = fopen("PT_test_command.txt", "r");

	int fnum, i, j, k, l;
	char fnamei[50], fnameo[50];
	fscanf(fp, "%d", &fnum);
	for (i = 0; i < fnum; i++)
	{
		FILE* fin, * fout;
		fscanf(fp, "%s %s", fnamei, fnameo);

		fin = fopen(fnamei, "r");
		fout = fopen(fnameo, "w");

		if (fin == NULL)
		{
			fclose(fin);
			fclose(fout);
			continue;
		}

		int num;
		double min, val;
		
		fscanf(fin, "%d", &num);
		XArr = (double*)malloc(sizeof(double) * num);
		YArr = (double*)malloc(sizeof(double) * num);
		for (j = 0; j < num; j++)
		{
			fscanf(fin, "%lf %lf", &(XArr[j]), &(YArr[j]));
		}

		table = (double**)malloc(sizeof(double*) * (num + 1));
		for (j = 0; j <= num; j++)
			table[j] = (double*)malloc(sizeof(double) * (num + 1));

		path = (int**)malloc(sizeof(int*) * (num + 1));
		for (j = 0; j <= num; j++)
			path[j] = (int*)malloc(sizeof(int) * (num + 1));
;

		// C[s][i] : �ִ� �� ������ �밢���� ���� (vi, vi+s-1 �� ���� �׻� ���ԵǹǷ� dist ���� �ش� �밢���� ���� �ȵ�)
		for (k = 0; k < 4; k++)
		{
			for (j = 0; j <= num; j++)
			{
				table[k][j] = 0;
				path[k][j] = -1;
			}
		}

		for (k = 4; k <= num; k++) // s
		{
			for (j = 0; j <= num - k; j++) // i
			{
				min = table[1 + 1][j] + table[k - 1][j + 1]
					+ dist(num, j, j + 1)
					+ dist(num, j + 1, j + k - 1);
				path[k][j] = 1;

				for (l = 2; l <= k - 2; l++) // k
				{
					val = table[l + 1][j] + table[k - l][j + l]
						+ dist(num, j, j + l)
						+ dist(num, j + l, j + k - 1);
					if (val < min)
					{
						min = val;
						path[k][j] = l;
					}
				}

				table[k][j] = min;
			}
		}

		fprintf(fout, "%lf\n", table[num][0]);
		CArr = (chord*)malloc(sizeof(chord) * (num - 3));
		Cnum = 0;
		save_path(num, num, 0);

		// sort CArr
		for (j = 0; j<num-3;j++)
			if (CArr[j].v1 > CArr[j].v2)
			{
				int temp = CArr[j].v1;
				CArr[j].v1 = CArr[j].v2;
				CArr[j].v2 = temp;
			}

		// 1st : v1�� sort
		Insertion_Sort1(CArr, 0, num - 4);
		
		
		// 2nd : v1������ v2�� sort
		int lptr = 0;
		for (j = 0; j < num - 3; j++)
		{
			if (CArr[j].v1 != CArr[lptr].v1)
			{
				if (lptr < j-1)
					Insertion_Sort2(CArr, lptr, j-1);
				lptr = j;
			}
		}	
		if (lptr < j - 1)
			Insertion_Sort2(CArr, lptr, j - 1);
	
		for (j = 0; j < num - 3; j++)
		{
			fprintf(fout, "%d %d\n", CArr[j].v1, CArr[j].v2);
		}
		
		free(CArr);
		for (j = 0; j <= num; j++)
		{
			free(table[j]);
			free(path[j]);
		}
		free(table);
		free(path);

		free(XArr);
		free(YArr);
		fclose(fin);
		fclose(fout);
	}

	fclose(fp);
	return 0;
}

int check_adj(int n, int v1, int v2) // True �� �밢����
{
	int u, d;
	if (v1 > v2)
	{
		u = v1;
		d = v2;
	}
	else if (v1 < v2)
	{
		u = v2;
		d = v1;
	}
	else
		return 0;

	if ((u + 1) % n == d || d + 1 == u)
		return 0;
	else
		return 1;

}

void save_path(int num, int i, int j)
{
	int key = path[i][j];
	if (key == -1)
		return;

	// key = k, i = s, j = i
	
	if (check_adj(num, j, j + key))
	{
		CArr[Cnum] = { j,j + key };
		Cnum++;
	}
	if (check_adj(num, j + key, j + i - 1))
	{
		CArr[Cnum] = { j + key,j + i - 1 };
		Cnum++;
	}
	save_path(num,key + 1, j);
	save_path(num,i - key, j + key);
}

double dist(int n,int v1, int v2)
{
	int u, d;
	if (v1 > v2)
	{
		u = v1;
		d = v2;
	}
	else if (v1 < v2)
	{
		u = v2;
		d = v1;
	}
	else
		return 0;

	if ((u+1)%n == d || d+1 == u)
		return 0;
	else
		return sqrt(pow(XArr[u] - XArr[d], 2) + pow(YArr[u] - YArr[d], 2));
}

void Insertion_Sort1(chord* data, int left, int right) {
	for (int i = left; i <= right; i++) {
		int key = data[i].v1;
		chord temp = data[i];
		int j = i - 1;
		for (; j >= 0 && key < data[j].v1; j--) {
			data[j + 1] = data[j];
		}
		data[j + 1] = temp;
	}
}

void Insertion_Sort2(chord* data, int left, int right) {
	for (int i = left; i <= right; i++) {
		int key = data[i].v2;
		chord temp = data[i];
		int j = i - 1;
		for (; j >= left && key < data[j].v2; j--) {
			data[j + 1] = data[j];
		}
		data[j + 1] = temp;
	}
}
